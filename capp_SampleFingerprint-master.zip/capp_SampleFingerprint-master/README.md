# capp_SampleFingerprint

This application demonstrates usage of CredenceID Fingerprint APIs. It goes over fingerprint capturing, WSQ conversions, template creation, and fingerprint matching.
