# capp_XamarinSampleFinger

This app demonstrates how to use Credence ID fingerprint APIs via Microsoft's Xamarin framework.
